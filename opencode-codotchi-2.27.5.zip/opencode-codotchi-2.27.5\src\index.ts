﻿/**
 * index.ts
 *
 * opencode-codotchi — npm-distributable OpenCode plugin.
 * Brings your codotchi into any terminal as a living companion.
 *
 * What this plugin does:
 *   - Loads pet state from both VS Code and PyCharm per-IDE state files on startup.
 *     VS Code : %APPDATA%/codotchi/vscode/state.json  (~/.config/codotchi/vscode/state.json)
 *     PyCharm : %APPDATA%/codotchi/pycharm/state.json (~/.config/codotchi/pycharm/state.json)
 *   - Watches both files for live updates from whichever IDE is active.
 *   - Runs a tick timer every TICK_INTERVAL_SECONDS to advance the game.
 *   - Hooks into file.edited events to reward coding activity.
 *   - Hooks into session.idle to flag idle state.
 *   - Hooks into server.connected to queue a greeting notification.
   *   - Registers the `codotchi` custom tool for slash-command interactions.
 *
 * Both pets are shown simultaneously when active (saved within the last 60 s).
 * If neither IDE is actively ticking, the most recently saved alive pet is shown.
 * Actions (feed, pat, etc.) are applied to all currently active pets.
 *
 * Slash commands (invoked via /codotchi in the OpenCode TUI):
 *   /codotchi              → show status (text + art if on)
 *   /codotchi feed         → give a meal
 *   /codotchi pat          → pat (gentle happiness boost)
 *   /codotchi sleep        → put to sleep
 *   /codotchi clean        → clean up droppings
 *   /codotchi medicine     → give medicine (cure sickness)
 *   /codotchi on           → enable ASCII art in tool details panel
 *   /codotchi off          → disable ASCII art (plain text stats only)
 *
 * Global install (from zip):
 *   1. Download opencode-codotchi-X.Y.Z.zip from Releases and extract it.
 *   2. cd opencode-codotchi-X.Y.Z && node bin/install.js --install
 *      Copies the /codotchi slash command, plugin source files, and adds
 *      the @opencode-ai/plugin dependency to ~/.config/opencode/package.json.
 *      OpenCode loads plugins from ~/.config/opencode/plugins/ automatically.
 */

import * as fs   from "fs";
import * as path from "path";
import * as os   from "os";
import { spawnSync } from "child_process";
import { tool }  from "@opencode-ai/plugin";
import type { Plugin, PluginInput } from "@opencode-ai/plugin";
import { getIDEBase as _getIDEBase, resolveVSCodeStatePath } from "./statePathResolver.js";
import { sumCompletedAssistantUsage, extractTimestampedUsage, TimestampedUsageEntry, buildDailyUsageQueries, defaultOpencodeDbPath, queryDailyUsageFromDb, UsageTotals } from "./usageBackfill.js";

import {
  PetState,
  GameConfig,
  tick,
  applyOfflineDecay,
  applyCodeActivity,
  feedMeal,
  startSnack,
  consumeSnack,
  pat,
  play,
  sleep,
  clean,
  giveMedicine,
  serialiseState,
  deserialiseState,
  createPet,
  DEFAULT_GAME_CONFIG,
  TICK_INTERVAL_SECONDS,
  CODE_ACTIVITY_THROTTLE_SECONDS,
} from "./gameEngine.js";
import { sealSerialisedState, verifySeal } from "./integrity.js";
import { translateV2Event, summariseNotification } from "./v2Events.js";

import {
  buildSpeechBubble,
  buildStatusBlock,
  buildToast,
  buildContextualSpeech,
  formatTokens,
  formatCost,
  stripAnsi,
  pickRandom,
  attentionCallSpeech,
  TODO_COMPLETE_PHRASES,
  SESSION_DIFF_PHRASES,
} from "./asciiArt.js";

// ---------------------------------------------------------------------------
// Per-IDE state file helpers
// ---------------------------------------------------------------------------

/** How recently (ms) a state file must have been saved to count as "active". */
const ACTIVE_IDE_THRESHOLD_MS = 60_000;

// Speech when a whim attention call is answered — one line picked at random.
// Mirrored in vscode/media/sidebar.js (shared by both IDEs) and claude-codotchi/scripts/whimSpeech.mjs.
const WHIM_ANSWER_SPEECH = {
  play:    ["Yay, you played with me!", "That's just what I wanted!", "Again! Again!", "Best game ever!"],
  pat:     ["Ahh, that's the spot.", "I needed that, thank you!", "More pats, please!", "You always know what I need."],
  craving: ["Mmm, just what I was craving!", "You read my mind!", "That hit the spot!", "Exactly what I wanted, yum!"],
};

function whimSpeech(call: keyof typeof WHIM_ANSWER_SPEECH): string {
  const lines = WHIM_ANSWER_SPEECH[call];
  return lines[Math.floor(Math.random() * lines.length)];
}

// ---------------------------------------------------------------------------
// OpenCode-local pet config — unkillable from neglect, normal aging speed
// ---------------------------------------------------------------------------

/** GameConfig used for the OpenCode-local pet: health floored at 1 (never dies
 *  from stat decay), but aging runs at the normal 1× rate (not the 10× dev speed). */
const LOCAL_PET_GAME_CONFIG: GameConfig = {
  ...DEFAULT_GAME_CONFIG,
  devMode: true,
  devModeHealthFloor: 1,
  devModeAgingMultiplier: 1,
};

/** Name pool for auto-created OpenCode-local pets. */
const LOCAL_PET_NAMES = ["Copilot"];

function getIDEBase(): string {
  return _getIDEBase();
}

/** Delegates to statePathResolver — scans for most-recently-modified state.json. */
function getVSCodeStatePath(): string {
  return resolveVSCodeStatePath();
}

function getPyCharmStatePath(): string {
  return path.join(getIDEBase(), "codotchi", "pycharm", "state.json");
}

/** Migrate state files from old gotchi/ folder to codotchi/ on first run. */
function migrateStateFolders(): void {
  const base = getIDEBase();
  const migrations: Array<[string, string]> = [
    [path.join(base, "gotchi", "vscode", "state.json"),  path.join(base, "codotchi", "vscode",  "state.json")],
    [path.join(base, "gotchi", "pycharm", "state.json"), path.join(base, "codotchi", "pycharm", "state.json")],
  ];
  for (const [oldPath, newPath] of migrations) {
    try {
      if (fs.existsSync(newPath)) { continue; }
      if (!fs.existsSync(oldPath)) { continue; }
      const newDir = path.dirname(newPath);
      if (!fs.existsSync(newDir)) { fs.mkdirSync(newDir, { recursive: true }); }
      fs.copyFileSync(oldPath, newPath);
    } catch { /* best-effort */ }
  }
}

interface IDEStateFile {
  state: Record<string, unknown>;
  savedAt: number;
  terminalEnabled?: boolean;
  /** Leaderboard integrity seal (see integrity.ts); absent in files from older builds. */
  seal?: string;
}

interface LocalStateFile {
  state: Record<string, unknown>;
  savedAt: number;
  createdDate?: string; // local date string "YYYY-MM-DD"
  totalMessages?: number; // Cumulative message count across days
}

function loadFromIDEFile(filePath: string): { state: PetState; savedAt: number; terminalEnabled: boolean } | null {
  try {
    if (!fs.existsSync(filePath)) { return null; }
    const raw = JSON.parse(fs.readFileSync(filePath, "utf8")) as IDEStateFile;
    if (!raw.state || typeof raw.savedAt !== "number") { return null; }
    return {
      state: verifySeal(deserialiseState(raw.state), raw.seal),
      savedAt: raw.savedAt,
      terminalEnabled: raw.terminalEnabled ?? true,
    };
  } catch {
    return null;
  }
}

function saveToIDEFile(filePath: string, state: PetState): void {
  try {
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) { fs.mkdirSync(dir, { recursive: true }); }
    const serialised = serialiseState(state) as Record<string, unknown>;
    const payload: IDEStateFile = {
      state: serialised,
      savedAt: Date.now(),
      seal: sealSerialisedState(serialised),
    };
    fs.writeFileSync(filePath, JSON.stringify(payload), "utf8");
  } catch {
    // Best-effort — never crash the plugin if the state file is unavailable.
  }
}

/** Persist only the terminalEnabled flag into the VS Code state file (primary). */
function saveTerminalEnabled(): void {
  try {
    const filePath = getVSCodeStatePath();
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) { fs.mkdirSync(dir, { recursive: true }); }
    let existing: IDEStateFile = { state: {}, savedAt: Date.now(), terminalEnabled };
    if (fs.existsSync(filePath)) {
      try { existing = JSON.parse(fs.readFileSync(filePath, "utf8")) as IDEStateFile; } catch { /* ignore */ }
    }
    existing.terminalEnabled = terminalEnabled;
    fs.writeFileSync(filePath, JSON.stringify(existing), "utf8");
  } catch {
    // Best-effort.
  }
}

// ---------------------------------------------------------------------------
// Daily usage sidecar helpers
// ---------------------------------------------------------------------------

function getDailyUsagePath(): string {
  return path.join(os.homedir(), ".config", "opencode", "codotchi-daily.json");
}

/** Local calendar date ("YYYY-MM-DD") — "today" for daily usage and the local pet. */
function todayLocal(nowMs: number = Date.now()): string {
  const d = new Date(nowMs);
  const pad = (n: number): string => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

/** Epoch ms of local midnight at the start of today. */
function todayStartLocalMs(nowMs: number = Date.now()): number {
  const d = new Date(nowMs);
  return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
}

function loadDailyUsage(): void {
  try {
    const filePath = getDailyUsagePath();
    if (!fs.existsSync(filePath)) { return; }
    const raw = JSON.parse(fs.readFileSync(filePath, "utf8")) as { date?: string; costUSD?: number; tokens?: number; messages?: number };
    const today = todayLocal();
    if (raw.date === today) {
      // Store into sidecar vars only — do NOT pre-seed dailyCostUSD.
      // backfillDailyUsage() will set dailyCostUSD from the authoritative SQLite
      // DB (Track A). The sidecar value is only used as a floor when Track A
      // fails and Track B is the sole source.
      sidecarCostUSD  = typeof raw.costUSD  === "number" ? raw.costUSD  : 0;
      sidecarTokens   = typeof raw.tokens   === "number" ? raw.tokens   : 0;
      sidecarMessages = typeof raw.messages === "number" ? raw.messages : 0;
    }
    // If stored date differs it's a new day — sidecar values stay zero
  } catch { /* best-effort */ }
}

function saveDailyUsage(fromDb: boolean = false): void {
  try {
    const filePath = getDailyUsagePath();
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) { fs.mkdirSync(dir, { recursive: true }); }
    const data: Record<string, unknown> = { date: dailyDate, costUSD: dailyCostUSD, tokens: dailyTokens, messages: dailyMessages };
    if (fromDb) { data.source = "db"; }
    fs.writeFileSync(filePath, JSON.stringify(data), "utf8");
  } catch { /* best-effort */ }
}

/** Resolve the OpenCode SQLite path: default location first, then the legacy `opencode db path` CLI. */
function resolveOpencodeDbPath(): string | undefined {
  const def = defaultOpencodeDbPath(process.env, os.homedir());
  if (fs.existsSync(def)) { return def; }
  try {
    const cli = findOpencodeCli();
    if (!cli) { return undefined; }
    const out = spawnSync(cli, ["db", "path"], { timeout: 5000, encoding: "utf8", windowsHide: true });
    const p = out.status === 0 ? out.stdout?.trim() : "";
    return p && fs.existsSync(p) ? p : undefined;
  } catch { return undefined; }
}

/** Today's cross-project totals from the OpenCode database, or undefined if unavailable. */
async function fetchDbDailyTotals(todayStartMs: number): Promise<UsageTotals | undefined> {
  const dbPath = resolveOpencodeDbPath();
  if (!dbPath) { return undefined; }
  const direct = await queryDailyUsageFromDb(dbPath, todayStartMs);
  if (direct) { return direct; }
  // Legacy fallback: OpenCode 1 shipped a `db` subcommand that can run SQL.
  try {
    const cli = findOpencodeCli();
    if (!cli) { return undefined; }
    for (const sql of buildDailyUsageQueries(todayStartMs)) {
      const r = spawnSync(cli, ["db", "--format", "json", sql], { timeout: 10000, encoding: "utf8", windowsHide: true });
      if (r.status === 0 && r.stdout) {
        const row = (JSON.parse(String(r.stdout).trim()) as Array<{ costUSD?: number; tokens?: number; messages?: number }>)[0] ?? {};
        return { costUSD: row.costUSD ?? 0, tokens: row.tokens ?? 0, messages: row.messages ?? 0 };
      }
    }
  } catch { /* fall through */ }
  return undefined;
}

const DB_REFRESH_MIN_INTERVAL_MS = 30_000;
let lastDbRefreshMs = 0;
let dbRefreshInFlight = false;

/**
 * Re-sync today's totals from the database (throttled). Live events only see
 * this window's replies, so without this the total drifts below the truth when
 * several OpenCode windows run at once.
 */
async function refreshDailyFromDb(): Promise<void> {
  if (!backfillComplete || dbRefreshInFlight) { return; }
  if (Date.now() - lastDbRefreshMs < DB_REFRESH_MIN_INTERVAL_MS) { return; }
  dbRefreshInFlight = true;
  lastDbRefreshMs = Date.now();
  try {
    const totals = await fetchDbDailyTotals(todayStartLocalMs());
    if (!totals) { return; }
    checkDayRollover();
    dailyCostUSD  = totals.costUSD;
    dailyTokens   = totals.tokens;
    dailyMessages = totals.messages;
    dailyDate = todayLocal();
    saveDailyUsage(true);
  } catch { /* best-effort */ } finally {
    dbRefreshInFlight = false;
  }
}

function checkDayRollover(): void {
  const today = todayLocal();
  if (dailyDate !== today) {
    dailyCostUSD    = 0;
    dailyTokens     = 0;
    dailyMessages   = 0;
    dailyDate       = today;
    sidecarCostUSD  = 0;
    sidecarTokens   = 0;
    sidecarMessages = 0;
    countedMessageIds.clear();
    // Daily reset for OpenCode-local pet — respawn with same name and message count
    if (localPetState !== null && localPetState.alive) {
      createLocalPet();
      advanceLocalPetStageIfNeeded();
    }
  }
}

// ---------------------------------------------------------------------------
// Backfill daily usage from historical sessions on startup
// ---------------------------------------------------------------------------

/**
 * Locate the opencode-cli binary by trying three candidate paths in order:
 *   1. %LOCALAPPDATA%\opencode\opencode-cli.exe  (Windows installer)
 *   2. ~/.local/share/opencode/opencode-cli      (Linux / Mac)
 *   3. "opencode" on PATH                        (generic fallback)
 * Returns the first path whose binary exits with status 0, or null if none found.
 */
function findOpencodeCli(): string | null {
  const candidates: string[] = [
    // Windows
    ...(process.env.LOCALAPPDATA
      ? [path.join(process.env.LOCALAPPDATA, "opencode", "opencode-cli.exe")]
      : []),
    // Linux / Mac
    path.join(os.homedir(), ".local", "share", "opencode", "opencode-cli"),
    // Generic PATH fallback (main opencode binary also has the `db` subcommand)
    "opencode",
  ];

  for (const c of candidates) {
    try {
      if (c !== "opencode" && !fs.existsSync(c)) { continue; }
      const result = spawnSync(c, ["--version"], { timeout: 2000, encoding: "utf8", windowsHide: true });
      if (result.status === 0) { return c; }
    } catch { /* try next */ }
  }
  return null;
}

/**
 * On startup, the module-level dailyCostUSD / dailyTokens accumulators are
 * seeded from the sidecar file (which only records what was observed during
 * previous plugin runs). This async helper uses a two-track approach:
 *
 * Track A — SQLite direct query (cross-project, single source of truth):
 *   Spawns the opencode-cli binary to run a SQL query against the OpenCode
 *   database. Filters on individual message completion timestamps so that
 *   cross-day sessions (started yesterday, still active today) are counted
 *   correctly — only their today-messages are included. This gives the same
 *   total as `opencode stats` and `agentsview usage statusline`.
 *   The DB value is assigned directly — Math.max is NOT used — so that a
 *   stale/inflated sidecar can never win over the authoritative DB total.
 *
 * Track B — API loop (current-project only, last-1h costEvents buffer):
 *   Calls client.session.list() + session.messages() for the current project
 *   to populate the rolling last-1h costEvents buffer used by lastHourUsage().
 *   Only sets dailyCostUSD/dailyTokens if Track A failed (fallback path).
 *   Math.max is kept here because the API can return an incomplete session
 *   list under timing races at startup.
 *
 * Both tracks run in sequence. If Track A fails (binary absent, DB missing,
 * query error), Track B's API totals are used instead (BUGFIX-133 behaviour).
 *
 * Called fire-and-forget from the plugin entry point so startup is never
 * delayed or blocked.
 */
async function backfillDailyUsage(client: PluginInput["client"]): Promise<void> {
  try {
    const today = todayLocal();
    const todayStartMs = todayStartLocalMs();

    // ------------------------------------------------------------------
    // Track A — cross-project daily totals via SQLite
    // ------------------------------------------------------------------
    let trackASucceeded = false;
    // Wall-clock time when the Track A DB snapshot was taken. Used as the
    // deduplication boundary for pendingLiveEvents replay: any message with
    // time.completed <= trackASnapshotTime is in the DB snapshot already.
    let trackASnapshotTime = 0;
    try {
      trackASnapshotTime = Date.now();
      const totals = await fetchDbDailyTotals(todayStartMs);
      if (totals) {
        checkDayRollover();
        // DB is the single source of truth — assign directly, never Math.max,
        // so an inflated sidecar from a bugged earlier run can't survive.
        dailyCostUSD  = totals.costUSD;
        dailyTokens   = totals.tokens;
        dailyMessages = totals.messages;
        trackASucceeded = true;
        lastDbRefreshMs = Date.now();
        // Persist immediately so other windows watching the file adopt it.
        dailyDate = today;
        saveDailyUsage(true);
      }
    } catch { /* Track A failed — fall through to Track B for cost totals */ }

    // ------------------------------------------------------------------
    // Track B — current-project API loop for last-1h costEvents buffer
    // ------------------------------------------------------------------
    const listResult = await client.session.list();
    const sessions = listResult.data ?? [];

    // Only fetch messages for sessions that were active today
    const todaySessions = sessions.filter(
      (s) => s.time.updated >= todayStartMs
    );

    let backfilledCost     = 0;
    let backfilledTokens   = 0;
    let backfilledMessages = 0;
    const oneHourAgo = Date.now() - 3_600_000;
    const backfilledEvents: TimestampedUsageEntry[] = [];
    // Track ALL backfilled message timestamps (not just the last-1h subset)
    // so latestBackfillTs reflects the true latest message across all of today.
    let latestBackfillTsAll = 0;

    for (const s of todaySessions) {
      try {
        const msgResult = await client.session.messages({ path: { id: s.id } });
        const messages = msgResult.data ?? [];
        if (!trackASucceeded) {
          // Track A failed — use API totals as fallback for cost/token totals
          // Only messages completed today — a session updated today may also
          // hold earlier days' messages, which must not inflate today's total.
          const totals = sumCompletedAssistantUsage(messages, todayStartMs);
          backfilledCost     += totals.costUSD;
          backfilledTokens   += totals.tokens;
          backfilledMessages += totals.messages;
        }
        // Always collect timestamped entries for the last-1h rolling buffer.
        const timestamped = extractTimestampedUsage(messages);
        for (const e of timestamped) {
          if (e.completedAt > latestBackfillTsAll) { latestBackfillTsAll = e.completedAt; }
          if (e.completedAt >= oneHourAgo) {
            backfilledEvents.push(e);
          }
        }
      } catch { /* skip individual session errors — best-effort */ }
    }

    // If Track A failed, apply Track B's API totals (current-project only fallback).
    if (!trackASucceeded) {
      checkDayRollover();
      // Use Math.max against sidecarCostUSD (not dailyCostUSD which is 0 at this point)
      // to handle the timing race where the API returns an incomplete session list.
      // sidecarCostUSD is the value from the last plugin run and acts as a floor,
      // but it is never seeded into dailyCostUSD pre-backfill to avoid propagating
      // an inflated stale value into the live accumulator.
      dailyCostUSD  = Math.max(sidecarCostUSD,  backfilledCost);
      dailyTokens   = Math.max(sidecarTokens,   backfilledTokens);
      dailyMessages = Math.max(sidecarMessages, backfilledMessages);
    }

    // Replay live events that arrived before backfill completed.
    // Deduplication boundary:
    //   - Track A succeeded: use trackASnapshotTime (the wall-clock instant the
    //     spawnSync DB query was issued). Any message with time.completed <=
    //     trackASnapshotTime is guaranteed to be in the DB snapshot already —
    //     regardless of which session it belongs to. Using latestBackfillTsAll
    //     here would be wrong because Track B only iterates sessions with
    //     time.updated >= todayStartMs, so cross-day sessions are excluded and
    //     their message timestamps never update latestBackfillTsAll, causing
    //     those messages to pass the guard and be double-counted on top of the
    //     DB total that Track A already assigned.
    //   - Track A failed: fall back to latestBackfillTsAll (Track B's max
    //     message timestamp) as before.
    const dedupeTs = trackASucceeded ? trackASnapshotTime : latestBackfillTsAll;
    for (const ev of pendingLiveEvents) {
      if (ev.completedAt > dedupeTs && ev.completedAt >= todayStartMs) {
        dailyCostUSD  += ev.cost;
        dailyTokens   += ev.tokens;
        dailyMessages += 1;
        // Also add to costEvents buffer for last-1h tracking
        costEvents.push({ completedAt: ev.completedAt, costUSD: ev.cost, tokens: ev.tokens });
      }
    }
    pendingLiveEvents = [];

    if (dailyCostUSD > 0 || dailyTokens > 0) {
      dailyDate = today;
      saveDailyUsage();
    }

    // Replace last-1h buffer with backfilled events (plus any replayed live events
    // appended above). Only keep backfill events if they aren't already there.
    if (backfilledEvents.length > 0) {
      // Merge: start from backfill, live replays were already appended above
      costEvents = [...backfilledEvents, ...costEvents];
      // Deduplicate by completedAt in case of any overlap
      const seen = new Set<number>();
      costEvents = costEvents.filter(e => { if (seen.has(e.completedAt)) return false; seen.add(e.completedAt); return true; });
    }

    // Mark backfill done — future live events go directly to dailyCostUSD.
    backfillComplete = true;
  } catch {
    // If backfill fails entirely, still unblock live events.
    backfillComplete = true;
    for (const ev of pendingLiveEvents) {
      dailyCostUSD  += ev.cost;
      dailyTokens   += ev.tokens;
      dailyMessages += 1;
      costEvents.push({ completedAt: ev.completedAt, costUSD: ev.cost, tokens: ev.tokens });
    }
    pendingLiveEvents = [];
    /* best-effort — never block startup */
  }
}

// ---------------------------------------------------------------------------
// Plugin config sidecar helpers (cost speech thresholds)
// ---------------------------------------------------------------------------

function getPluginConfigPath(): string {
  return path.join(os.homedir(), ".config", "opencode", "codotchi-config.json");
}

function loadPluginConfig(): void {
  try {
    const filePath = getPluginConfigPath();
    if (!fs.existsSync(filePath)) { return; }
    const raw = JSON.parse(fs.readFileSync(filePath, "utf8")) as { costWarnThreshold?: number; costShoutThreshold?: number };
    if (typeof raw.costWarnThreshold  === "number" && raw.costWarnThreshold  > 0) { costWarnThreshold  = raw.costWarnThreshold; }
    if (typeof raw.costShoutThreshold === "number" && raw.costShoutThreshold > 0) { costShoutThreshold = raw.costShoutThreshold; }
  } catch { /* best-effort */ }
}

function savePluginConfig(): void {
  try {
    const filePath = getPluginConfigPath();
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) { fs.mkdirSync(dir, { recursive: true }); }
    fs.writeFileSync(filePath, JSON.stringify({ costWarnThreshold, costShoutThreshold }), "utf8");
  } catch { /* best-effort */ }
}

// ---------------------------------------------------------------------------
// OpenCode-local pet sidecar helpers
// ---------------------------------------------------------------------------

function getLocalStatePath(): string {
  return path.join(os.homedir(), ".config", "opencode", "codotchi-local.json");
}

/** Total messages (persisted across daily resets) for message-based aging. */
let localPetTotalMessages = 0;

/** Message thresholds for stage progression. 100 messages per stage, doubling interval. */
function stageForMessages(n: number): string {
  if (n < 100) return "baby";
  if (n < 300) return "child";
  if (n < 700) return "teen";
  if (n < 1500) return "adult";
  return "senior";
}

/** Pin companion stats to healthy values (no hunger, no decay). */
function pinnedCompanionStats(state: PetState): PetState {
  return {
    ...state,
    hunger: 100,
    happiness: 100,
    energy: 100,
    health: 100,
    sick: false,
    poops: 0,
  };
}

/** Advance local pet to the correct stage based on total message count. */
function advanceLocalPetStageIfNeeded(): void {
  if (localPetState === null || !localPetState.alive) { return; }
  const targetStage = stageForMessages(localPetTotalMessages);
  if (targetStage === localPetState.stage) { return; }
  
  // Advance stage using type assertion
  const updated: any = {
    ...localPetState,
    stage: targetStage,
  };
  localPetState = pinnedCompanionStats(updated);
  
  // Queue evolution notification
  const ideLabel = "[OpenCode]";
  const stageName = targetStage;
  queueNotification(terminalEnabled && localPetState
    ? buildSpeechBubble(localPetState.stage, localPetState.mood, pickRandom([`I evolved into a ${stageName}!`, `I'm a ${stageName} now!`, `Growing up — now a ${stageName}.`]), localPetState.name, localPetState.spriteType, ideLabel)
    : `${ideLabel} ${localPetState.name}: ${pickRandom([`I evolved into a ${stageName}!`, `I'm a ${stageName} now!`, `Growing up — now a ${stageName}.`])}`);
  
  saveLocalState();
}

function loadLocalState(): void {
  try {
    const filePath = getLocalStatePath();
    if (!fs.existsSync(filePath)) {
      createLocalPet();
      return;
    }
    const raw = JSON.parse(fs.readFileSync(filePath, "utf8")) as LocalStateFile;
    if (!raw.state || typeof raw.savedAt !== "number") {
      createLocalPet();
      return;
    }
    
    // Load persistent message count before checking date
    localPetTotalMessages = typeof raw.totalMessages === "number" ? raw.totalMessages : 0;
    
    // Check if the pet was created on a different day — if so, respawn
    const createdDate = raw.createdDate ?? null;
    const today = todayLocal();
    if (createdDate !== today) {
      // New day — respawn the pet and set its stage based on message count
      createLocalPet();
      advanceLocalPetStageIfNeeded();
      return;
    }
    
    const elapsed = (Date.now() - raw.savedAt) / 1_000;
    localPetState    = pinnedCompanionStats(applyOfflineDecay(deserialiseState(raw.state), elapsed));
    localLastSavedAt = raw.savedAt;
    localMeals = 0;
    // If the pet is dead (old age), immediately respawn
    if (!localPetState.alive) {
      createLocalPet();
      advanceLocalPetStageIfNeeded();
    }
  } catch {
    createLocalPet();
  }
}

function saveLocalState(): void {
  try {
    if (localPetState === null) { return; }
    const filePath = getLocalStatePath();
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) { fs.mkdirSync(dir, { recursive: true }); }
    const payload: LocalStateFile = {
      state: serialiseState(localPetState) as Record<string, unknown>,
      savedAt: Date.now(),
      createdDate: todayLocal(),
      totalMessages: localPetTotalMessages,
    };
    fs.writeFileSync(filePath, JSON.stringify(payload), "utf8");
    localLastSavedAt = payload.savedAt;
  } catch { /* best-effort */ }
}

function createLocalPet(): void {
  const name = pickRandom(LOCAL_PET_NAMES);
  localPetState = pinnedCompanionStats(createPet(name, "codeling"));
  // Set the stage based on current message count
  (localPetState as any).stage = stageForMessages(localPetTotalMessages);
  localMeals = 0;
  saveLocalState();
  queueNotification(terminalEnabled && localPetState
    ? buildSpeechBubble(localPetState.stage, localPetState.mood,
        `Hi! I'm ${name}. I live in OpenCode — no IDE needed.`,
        name, localPetState.spriteType, "[OpenCode]")
    : `[OpenCode] ${name}: Hi! I'm ${name}. I live in OpenCode — no IDE needed.`);
}

// ---------------------------------------------------------------------------
// Meals-per-cycle counters (plugin-local, reset on wake, one per source)
// ---------------------------------------------------------------------------

let vscodeMeals  = 0;
let pycharmMeals = 0;
let localMeals   = 0;

// ---------------------------------------------------------------------------
// Plugin state — dual-pet (VS Code + PyCharm, independent)
// ---------------------------------------------------------------------------

/** VS Code pet state, or null if no VS Code state file exists. */
let vscodePetState:    PetState | null = null;
let vscodeLastSavedAt: number = 0;

/** PyCharm pet state, or null if no PyCharm state file exists. */
let pycharmPetState:    PetState | null = null;
let pycharmLastSavedAt: number = 0;

/** OpenCode-local pet — always exists, unkillable from neglect. */
let localPetState:    PetState | null = null;
let localLastSavedAt: number = 0;

let tickTimer: ReturnType<typeof setInterval> | undefined;
let isIdle = false;
let lastCodeActivityMs = 0;

// ---------------------------------------------------------------------------
// Display toggle (default on)
// ---------------------------------------------------------------------------

let terminalEnabled = true;

// ---------------------------------------------------------------------------
// Session coding activity stats (for contextual speech bubble commentary)
// ---------------------------------------------------------------------------

let sessionFilesEdited = 0;
let sessionStartMs = Date.now();
/** Unix ms of the last file.edited event; used to detect long idle stretches. */
let lastFileEditMs = 0;
/** Number of user messages sent this session; used for prompting-a-lot commentary. */
let sessionUserMessages = 0;
/** User message IDs already counted in sessionUserMessages. */
const countedUserMessageIds = new Set<string>();
/** True once the "can I help?" offer has been shown this session — fires only once. */
let hasOfferedHelp = false;

// ---------------------------------------------------------------------------
// Daily usage tracking (persisted to codotchi-daily.json sidecar)
// Accumulates cost + token spend across all OpenCode sessions today (local calendar day).
// ---------------------------------------------------------------------------

/** Session-level cost accumulator (reset on session.created). */
let sessionCostUSD = 0;
/** Session-level token accumulator (reset on session.created). */
let sessionTokens  = 0;
/** How many assistant messages this session (drives local-pet evolution). */
let localPetSessionMessages = 0;

/** Running daily USD cost (set by backfillDailyUsage on startup, reset at local midnight). */
let dailyCostUSD = 0;
/** Running daily token count (set by backfillDailyUsage on startup, reset at local midnight). */
let dailyTokens  = 0;
/**
 * Count of completed assistant messages today (set by backfillDailyUsage on
 * startup, reset at local midnight). Used as the denominator for the
 * tokens-per-message average shown in the speech bubble — dailyTokens /
 * dailyMessages. Incremented at the exact same point dailyTokens is, so the
 * two values are always in sync (no separate filtering needed).
 */
let dailyMessages = 0;
/** Local date string "YYYY-MM-DD" for the currently stored daily totals. */
let dailyDate    = "";

/**
 * Sidecar values loaded at startup — kept separate from dailyCostUSD so that
 * a stale/inflated sidecar cannot pre-poison the live accumulator.
 * backfillDailyUsage() uses these as a floor for the Track B fallback only;
 * Track A (SQLite) always overwrites them entirely and ignores sidecarCostUSD.
 */
let sidecarCostUSD  = 0;
let sidecarTokens   = 0;
let sidecarMessages = 0;

/**
 * Set of message IDs already counted toward dailyCostUSD/dailyTokens this day.
 * Prevents double-counting when message.updated fires multiple times for the
 * same message (e.g. once per streaming chunk before the final completion).
 * Cleared on local day rollover in checkDayRollover().
 */
const countedMessageIds = new Set<string>();

/**
 * Set to true once backfillDailyUsage() has finished.
 * Live message.updated events that arrive before backfill completes are held
 * in pendingLiveEvents and replayed after the backfill result is known — this
 * prevents the backfill from double-counting a message that was already
 * incremented by a live event.
 */
let backfillComplete = false;

/** Live cost/token events that arrived while backfill was still running. */
let pendingLiveEvents: Array<{ cost: number; tokens: number; completedAt: number }> = [];

// ---------------------------------------------------------------------------
// Rolling last-1h cost buffer (in-memory only, backfilled on startup)
// ---------------------------------------------------------------------------

/** Each entry represents one completed assistant message with its timestamp. */
let costEvents: TimestampedUsageEntry[] = [];

/** Sum cost and tokens for all events completed within the last 60 minutes. */
function lastHourUsage(): { costUSD: number; tokens: number } {
  const cutoff = Date.now() - 3_600_000;
  let costUSD = 0;
  let tokens  = 0;
  for (const e of costEvents) {
    if (e.completedAt >= cutoff) {
      costUSD += e.costUSD;
      tokens  += e.tokens;
    }
  }
  return { costUSD, tokens };
}

// ---------------------------------------------------------------------------
// Configurable cost speech thresholds (persisted to codotchi-config.json)
// ---------------------------------------------------------------------------

/** Daily cost (USD) at which the pet switches to a warning tone. */
let costWarnThreshold  = 30;
/** Daily cost (USD) at which the pet switches to ALL CAPS shouting. */
let costShoutThreshold = 50;

// ---------------------------------------------------------------------------
// Todo tracking — detect status transitions for celebratory notifications
// ---------------------------------------------------------------------------

/** Map of todo id → last known status, used to detect transitions. */
let prevTodos: Map<string, string> = new Map();

// ---------------------------------------------------------------------------
// Diff tracking — flag when AI has shipped changes since last idle
// ---------------------------------------------------------------------------

/** True when at least one session.diff with non-empty diff arrived since the
 *  last session.idle. The notification fires on the NEXT session.idle so we
 *  don't interrupt mid-burst. */
let pendingDiffSinceIdle = false;
/** True when the current branch is main, master, release/x, or prod — triggers cautious diff commentary. */
let isOnProdBranch = false;

// Timers and watchers created by the plugin entry point, torn down on unload.
const disposers: Array<() => void> = [];

// ---------------------------------------------------------------------------
// Pending notification queue
// Tick events fire outside any tool context, so we queue their messages
// and prepend them to the next tool result.
// ---------------------------------------------------------------------------

let pendingNotification: string | null = null;

// Stores the last execute() return value so tool.execute.after can mirror it
// to the details panel via output.output.
let lastToolOutput = "";

// Live rank cache — refreshed at most every 5 minutes from leaderboard/scores.json.
let liveRankCache: { rank: number; total: number; at: number } | null = null;
const RANK_CACHE_TTL_MS_OC = 5 * 60 * 1000;
const SCORES_JSON_URL_OC = "https://raw.githubusercontent.com/dylscoop/codotchi/leaderboard/leaderboard/scores.json";
const LIVE_JSON_URL_OC   = "https://raw.githubusercontent.com/dylscoop/codotchi/leaderboard/leaderboard/live.json";

const STAGE_ORDER_OC: Record<string, number> = { egg: 0, baby: 1, child: 2, teen: 3, adult: 4, senior: 5 };
const LIVE_STALE_MS_OC = 48 * 60 * 60 * 1000; // matches leaderboard/index.html

type RankEntry = { ageDays?: number; stage?: string; spawnedAt?: number; updatedAt?: number };

/** Rank the pet the way leaderboard/index.html orders rows: live entries only if
 *  pushed within 48h, stage then stored ageDays (no extrapolation), and the pet's
 *  own live entry (by spawnedAt) excluded so the +1 counts it once. */
async function refreshLiveRank(me: { ageDays?: number; stage?: string; spawnedAt?: number }): Promise<void> {
  const now = Date.now();
  if (liveRankCache && now - liveRankCache.at < RANK_CACHE_TTL_MS_OC) { return; }
  try {
    const [scoresRes, liveRes] = await Promise.all([
      fetch(SCORES_JSON_URL_OC),
      fetch(LIVE_JSON_URL_OC).catch(() => null),
    ]);
    if (!scoresRes.ok) { return; }
    const json = await scoresRes.json() as Record<string, unknown> | Array<unknown>;
    const scores: RankEntry[] = Array.isArray(json)
      ? (json as RankEntry[])
      : ((json as Record<string, unknown>).scores as RankEntry[] ?? []);
    const liveJson: RankEntry[] = liveRes?.ok
      ? await liveRes.json().catch(() => []) : [];
    const freshLive = (Array.isArray(liveJson) ? liveJson : [])
      .filter(e => typeof e.updatedAt === "number" && now - e.updatedAt < LIVE_STALE_MS_OC)
      .filter(e => !(me.spawnedAt && e.spawnedAt === me.spawnedAt));
    const combined = scores.concat(freshLive);
    const myStage = STAGE_ORDER_OC[me.stage ?? ""] ?? 0;
    const myAge = me.ageDays ?? 0;
    const rank = combined.filter(s => {
      const st = STAGE_ORDER_OC[s.stage ?? ""] ?? 0;
      return st !== myStage ? st > myStage : (s.ageDays ?? 0) > myAge;
    }).length + 1;
    liveRankCache = { rank, total: combined.length + 1, at: now };
  } catch { /* network failure — keep stale */ }
}

/** Set by the V2 entry point so queued notifications can also be pushed to the TUI as toasts. */
let notificationListener: ((msg: string) => void) | null = null;

function queueNotification(msg: string): void {
  // V2 shows notifications as TUI toasts, so don't also replay them in tool output.
  if (notificationListener) { notificationListener(msg); return; }
  // If a notification is already pending, append (newline-separated)
  pendingNotification = pendingNotification ? pendingNotification + "\n" + msg : msg;
}

/** Prepend msg to the front of the pending notification queue (so it appears before any already-queued messages). */
function prependNotification(msg: string): void {
  if (notificationListener) { notificationListener(msg); return; }
  pendingNotification = pendingNotification ? msg + "\n" + pendingNotification : msg;
}

/** Drain and return any pending notification, then clear it. */
function drainNotification(): string {
  if (pendingNotification === null) { return ""; }
  const msg = pendingNotification;
  pendingNotification = null;
  return msg + "\n\n";
}

/**
 * Returns the contextual art header (speech bubble) for all active pets when
 * terminalEnabled is true. Pets are stacked vertically, separated by a blank line.
 * Always call this AFTER any state-mutating operation so the art reflects updated stats.
 */
function artHeader(): string {
  if (!terminalEnabled) { return ""; }
  const active = getActivePets();
  if (active.length === 0) { return ""; }
  const alivePets = active.filter(p => p.state.alive);
  if (alivePets.length === 0) { return ""; }

  // Trigger a background rank refresh (fire-and-forget) on each artHeader call.
  const firstAlive = alivePets[0];
  void refreshLiveRank(firstAlive.state);

  const bubbles = alivePets
    .map(p => {
      const _1h0 = lastHourUsage();
      const { message: speech, bubbleColor } = buildContextualSpeech(p.state, sessionFilesEdited, Date.now() - sessionStartMs, lastFileEditMs > 0 ? Date.now() - lastFileEditMs : 0, sessionUserMessages, isOnProdBranch, dailyCostUSD, dailyTokens, costWarnThreshold, costShoutThreshold, _1h0.costUSD, _1h0.tokens, dailyMessages);
      const ideLabel = p.ide === "vscode" ? "[VS Code]" : p.ide === "pycharm" ? "[PyCharm]" : "[OpenCode]";
      return buildSpeechBubble(p.state.stage, p.state.mood, speech, p.state.name, p.state.spriteType, ideLabel, bubbleColor);
    })
    .join("\n");

  const rankLine = liveRankCache
    ? `  Rank #${liveRankCache.rank} of ${liveRankCache.total} on the leaderboard\n`
    : "";

  return bubbles + "\n" + rankLine;
}

// ---------------------------------------------------------------------------
// Active-pet helpers
// ---------------------------------------------------------------------------

interface ActivePet {
  ide:   "vscode" | "pycharm" | "opencode";
  state: PetState;
  /** Whether this IDE is currently ticking (savedAt within ACTIVE_IDE_THRESHOLD_MS). */
  live:  boolean;
}

/**
 * Returns pets to show in the current interaction:
 *   - All IDEs whose state file was saved within ACTIVE_IDE_THRESHOLD_MS → "live"
 *   - The OpenCode-local pet is shown when no IDE pet is live.
 *   - At least one pet is always returned if any alive pet exists.
 */
function getActivePets(): ActivePet[] {
  const now = Date.now();
  const idePets: ActivePet[] = [];

  if (vscodePetState !== null && vscodePetState.alive) {
    const live = (now - vscodeLastSavedAt) <= ACTIVE_IDE_THRESHOLD_MS;
    idePets.push({ ide: "vscode",  state: vscodePetState,  live });
  }
  if (pycharmPetState !== null && pycharmPetState.alive) {
    const live = (now - pycharmLastSavedAt) <= ACTIVE_IDE_THRESHOLD_MS;
    idePets.push({ ide: "pycharm", state: pycharmPetState, live });
  }

  const liveIDEPets = idePets.filter(p => p.live);

  // If any IDE pet is live, return only those — local pet steps aside
  if (liveIDEPets.length > 0) { return liveIDEPets; }

  // No live IDE pet — show the local pet (always "live" in-process)
  if (localPetState !== null && localPetState.alive) {
    return [{ ide: "opencode", state: localPetState, live: true }];
  }

  // Fallback: IDE pets exist but none live — return most recently saved alive IDE pet
  if (idePets.length > 0) {
    const newest = idePets.reduce((a, b) =>
      (a.ide === "vscode" ? vscodeLastSavedAt : pycharmLastSavedAt) >=
      (b.ide === "vscode" ? vscodeLastSavedAt : pycharmLastSavedAt) ? a : b
    );
    return [newest];
  }

  // No alive pet at all — include dead IDE pets for the "died" message
  const dead: ActivePet[] = [];
  if (vscodePetState !== null)  { dead.push({ ide: "vscode",  state: vscodePetState,  live: false }); }
  if (pycharmPetState !== null) { dead.push({ ide: "pycharm", state: pycharmPetState, live: false }); }
  if (dead.length > 0) {
    const newest = dead.reduce((a, b) =>
      (a.ide === "vscode" ? vscodeLastSavedAt : pycharmLastSavedAt) >=
      (b.ide === "vscode" ? vscodeLastSavedAt : pycharmLastSavedAt) ? a : b
    );
    return [newest];
  }
  // Last resort: return local pet even if dead
  if (localPetState !== null) {
    return [{ ide: "opencode", state: localPetState, live: false }];
  }
  return [];
}

function getMeals(ide: "vscode" | "pycharm" | "opencode"): number {
  if (ide === "vscode") { return vscodeMeals; }
  if (ide === "pycharm") { return pycharmMeals; }
  return localMeals;
}
function setMeals(ide: "vscode" | "pycharm" | "opencode", n: number): void {
  if (ide === "vscode") { vscodeMeals = n; }
  else if (ide === "pycharm") { pycharmMeals = n; }
  else { localMeals = n; }
}
function getSavedAt(ide: "vscode" | "pycharm" | "opencode"): number {
  if (ide === "vscode") { return vscodeLastSavedAt; }
  if (ide === "pycharm") { return pycharmLastSavedAt; }
  return localLastSavedAt;
}
function setSavedAt(ide: "vscode" | "pycharm" | "opencode", t: number): void {
  if (ide === "vscode") { vscodeLastSavedAt = t; }
  else if (ide === "pycharm") { pycharmLastSavedAt = t; }
  else { localLastSavedAt = t; }
}
function setPetState(ide: "vscode" | "pycharm" | "opencode", s: PetState): void {
  if (ide === "vscode") { vscodePetState = s; }
  else if (ide === "pycharm") { pycharmPetState = s; }
  else { localPetState = s; }
}
function getStatePath(ide: "vscode" | "pycharm"): string {
  return ide === "vscode" ? getVSCodeStatePath() : getPyCharmStatePath();
}

// ---------------------------------------------------------------------------
// Load / save / tick
// ---------------------------------------------------------------------------

/** Load all IDE state files + local pet on startup. */
function loadAllStates(): void {
  const vscodeFile  = loadFromIDEFile(getVSCodeStatePath());
  if (vscodeFile !== null) {
    const elapsed = (Date.now() - vscodeFile.savedAt) / 1_000;
    vscodePetState    = applyOfflineDecay(vscodeFile.state, elapsed);
    vscodeLastSavedAt = vscodeFile.savedAt;
    vscodeMeals = 0;
    // Restore terminalEnabled from the VS Code state file (respects explicit off)
    terminalEnabled = vscodeFile.terminalEnabled;
  }
  const pycharmFile = loadFromIDEFile(getPyCharmStatePath());
  if (pycharmFile !== null) {
    const elapsed = (Date.now() - pycharmFile.savedAt) / 1_000;
    pycharmPetState    = applyOfflineDecay(pycharmFile.state, elapsed);
    pycharmLastSavedAt = pycharmFile.savedAt;
    pycharmMeals = 0;
  }
  // Always load (or create) the OpenCode-local pet
  loadLocalState();
}

function saveIDEState(ide: "vscode" | "pycharm" | "opencode"): void {
  if (ide === "opencode") {
    saveLocalState();
    return;
  }
  const state = ide === "vscode" ? vscodePetState : pycharmPetState;
  if (state !== null) {
    saveToIDEFile(getStatePath(ide), state);
    setSavedAt(ide, Date.now());
  }
}

function applyTickForPet(ide: "vscode" | "pycharm"): void {
  const state = ide === "vscode" ? vscodePetState : pycharmPetState;
  if (state === null || !state.alive) { return; }
  const next = tick(state, isIdle, false, DEFAULT_GAME_CONFIG);
  setPetState(ide, next);
  saveIDEState(ide);

  const ideLabel = ide === "vscode" ? "[VS Code]" : "[PyCharm]";

  for (const event of next.events) {
    switch (event) {
      case "auto_woke_up":
        setMeals(ide, 0);
        queueNotification(terminalEnabled
          ? buildSpeechBubble(next.stage, next.mood, pickRandom(["I feel rested! Time to code!", "Recharged. Ready to go.", "Back and ready."]), next.name, next.spriteType, ideLabel)
          : `${ideLabel} ${next.name}: ${pickRandom(["I feel rested! Time to code!", "Recharged. Ready to go.", "Back and ready."])}`);
        break;
      case "break_nap_over":
        setMeals(ide, 0);
        queueNotification(terminalEnabled
          ? buildSpeechBubble(next.stage, next.mood, "Break's over! Ready to code.", next.name, next.spriteType, ideLabel)
          : `${ideLabel} ${next.name}: Break's over! Ready to code.`);
        break;
      case "died":
        queueNotification(terminalEnabled
          ? buildSpeechBubble(next.stage, "sad", pickRandom(["Goodbye... take care of the next one.", "It was good while it lasted. See you next time.", "Farewell. Start fresh when you're ready."]), next.name, next.spriteType, ideLabel)
          : `${ideLabel} ${next.name}: ${pickRandom(["Goodbye... take care of the next one.", "It was good while it lasted. See you next time.", "Farewell. Start fresh when you're ready."])}`);
        break;
      case "died_of_old_age":
        queueNotification(terminalEnabled
          ? buildSpeechBubble(next.stage, "sleeping", pickRandom(["I lived a full life. Thank you for everything.", "What a journey. Thank you.", "A full life, well lived."]), next.name, next.spriteType, ideLabel)
          : `${ideLabel} ${next.name}: ${pickRandom(["I lived a full life. Thank you for everything.", "What a journey. Thank you.", "A full life, well lived."])}`);
        break;
      case "evolved_to_baby":
      case "evolved_to_child":
      case "evolved_to_teen":
      case "evolved_to_adult":
      case "evolved_to_senior": {
        const stageName = event.replace("evolved_to_", "");
        queueNotification(terminalEnabled
          ? buildSpeechBubble(next.stage, next.mood, pickRandom([`I evolved into a ${stageName}!`, `I'm a ${stageName} now!`, `Growing up — now a ${stageName}.`]), next.name, next.spriteType, ideLabel)
          : `${ideLabel} ${next.name}: ${pickRandom([`I evolved into a ${stageName}!`, `I'm a ${stageName} now!`, `Growing up — now a ${stageName}.`])}`);
        break;
      }
      case "attention_call_hunger":
      case "attention_call_unhappiness":
      case "attention_call_sick":
      case "attention_call_critical_health":
      case "attention_call_low_energy":
      case "attention_call_poop":
      case "attention_call_gift":
      case "attention_call_break":
      case "attention_call_misbehaviour":
      case "attention_call_play":
      case "attention_call_pat":
      case "attention_call_craving_meal":
      case "attention_call_craving_snack":
      {
        const call = attentionCallSpeech(event.replace("attention_call_", ""));
        if (call) {
          queueNotification(terminalEnabled
            ? buildSpeechBubble(next.stage, call.mood, call.message, next.name, next.spriteType, ideLabel)
            : `${ideLabel} ${next.name}: ${call.message}`);
        }
        break;
      }
      case "became_sick":
        queueNotification(buildToast(next.stage, `${ideLabel} ${next.name} has fallen sick.`));
        break;
      case "pooped":
        queueNotification(buildToast(next.stage, `${ideLabel} ${next.name} made a mess! (use /codotchi clean)`));
        break;
    }
  }
}

function applyTick(): void {
  applyTickForPet("vscode");
  applyTickForPet("pycharm");
  applyTickForLocal();
}

// ---------------------------------------------------------------------------
// OpenCode-local pet tick
// ---------------------------------------------------------------------------

function applyTickForLocal(): void {
  if (localPetState === null || !localPetState.alive) { return; }
  const next = tick(localPetState, isIdle, false, LOCAL_PET_GAME_CONFIG);
  // Pin stats to healthy values for companion-only mode
  localPetState = pinnedCompanionStats(next);
  saveLocalState();

  const ideLabel = "[OpenCode]";

  // Only handle evolution events; ignore all stat-based events (hunger, happiness, etc.)
  for (const event of next.events) {
    switch (event) {
      case "evolved_to_baby":
      case "evolved_to_child":
      case "evolved_to_teen":
      case "evolved_to_adult":
      case "evolved_to_senior": {
        const stageName = event.replace("evolved_to_", "");
        queueNotification(terminalEnabled && localPetState
          ? buildSpeechBubble(localPetState.stage, localPetState.mood, pickRandom([`I evolved into a ${stageName}!`, `I'm a ${stageName} now!`, `Growing up — now a ${stageName}.`]), localPetState.name, localPetState.spriteType, ideLabel)
          : `${ideLabel} ${localPetState.name}: ${pickRandom([`I evolved into a ${stageName}!`, `I'm a ${stageName} now!`, `Growing up — now a ${stageName}.`])}`);
        break;
      }
      // All other events (hunger, happiness, energy, sickness, poop, gift,
      // misbehaviour, etc.) are intentionally ignored for the OpenCode-local pet —
      // its stats are pinned to healthy values and do not require user attention.
    }
  }
}

// ---------------------------------------------------------------------------
// Plugin entry point
// ---------------------------------------------------------------------------

const plugin: Plugin = async (ctx) => {
  // Migrate state files from old gotchi/ folder to codotchi/ on first run.
  migrateStateFolders();
  // Load daily usage + plugin config sidecars
  loadDailyUsage();
  loadPluginConfig();
  // Backfill daily usage from historical sessions (fire-and-forget)
  backfillDailyUsage(ctx.client).catch(() => { /* best-effort */ });
  // Load all IDE state files + local pet on startup — queue greetings as pending notifications
  loadAllStates();

  for (const p of getActivePets().filter(p => p.state.alive)) {
    const s = p.state;
    const ideLabel = p.ide === "vscode" ? "[VS Code]" : p.ide === "pycharm" ? "[PyCharm]" : "[OpenCode]";
    const greetMsg = p.ide === "opencode"
      ? `I'm here. I live in OpenCode — no IDE needed.`
      : `I'm here. ${
          s.hunger < 30 ? "Pretty hungry though." :
          s.sick        ? "Not feeling great."    :
          s.energy < 20 ? "A bit tired."          :
          pickRandom(["Let's get to work.", "Let's build something."])
        }`;
    queueNotification(terminalEnabled
      ? buildSpeechBubble(s.stage, s.mood, greetMsg, s.name, s.spriteType, ideLabel)
      : `${ideLabel} ${s.name}: ${greetMsg}`);
  }

  // Tick timer
  tickTimer = setInterval(() => {
    applyTick();
  }, TICK_INTERVAL_SECONDS * 1_000);
  disposers.push(() => { clearInterval(tickTimer); tickTimer = undefined; });

  // ---------------------------------------------------------------------------
  // Live sync — watch both IDE state files for external writes.
  // A 150 ms debounce absorbs rapid successive fs events from atomic writes.
  // The savedAt <= lastSavedAt guard prevents us from overwriting a state we
  // just saved ourselves (e.g. after /codotchi feed).
  // ---------------------------------------------------------------------------
  function makeIDEWatcher(ide: "vscode" | "pycharm"): void {
    const filePath = getStatePath(ide);
    let syncDebounce: ReturnType<typeof setTimeout> | undefined;
    let fsWatcher: ReturnType<typeof fs.watch> | undefined;

    const reload = (): void => {
      const loaded = loadFromIDEFile(filePath);
      if (loaded === null) { return; }
      if (loaded.savedAt <= getSavedAt(ide)) { return; }
      const elapsed = (Date.now() - loaded.savedAt) / 1_000;
      const prevState = ide === "vscode" ? vscodePetState : pycharmPetState;
      const wasDeadOrAbsent = prevState === null || !prevState.alive;
      const nowAlive = loaded.state.alive;
      // New pet spawned: flush stale queued notifications from the dead pet
      if (wasDeadOrAbsent && nowAlive) { pendingNotification = null; }
      setPetState(ide, applyOfflineDecay(loaded.state, elapsed));
      setSavedAt(ide, loaded.savedAt);
      setMeals(ide, 0);
    };

    const onChange = (): void => {
      if (syncDebounce !== undefined) { clearTimeout(syncDebounce); }
      syncDebounce = setTimeout(() => { syncDebounce = undefined; reload(); }, 150);
    };

    const startWatcher = (): void => {
      if (fsWatcher !== undefined) { return; }
      try {
        fsWatcher = fs.watch(filePath, { persistent: false }, onChange);
        fsWatcher.on("error", () => { fsWatcher?.close(); fsWatcher = undefined; });
      } catch { /* file may not exist yet — watchBootstrap will retry */ }
    };

    startWatcher();
    const watchBootstrap = setInterval(() => {
      if (fsWatcher !== undefined) { clearInterval(watchBootstrap); return; }
      startWatcher();
      if (fsWatcher !== undefined) { clearInterval(watchBootstrap); }
    }, 10_000);
    disposers.push(() => {
      clearInterval(watchBootstrap);
      if (syncDebounce !== undefined) { clearTimeout(syncDebounce); }
      fsWatcher?.close();
      fsWatcher = undefined;
    });
  }

  makeIDEWatcher("vscode");
  makeIDEWatcher("pycharm");

  // ---------------------------------------------------------------------------
  // Cross-window daily usage sync — watch codotchi-daily.json for writes from
  // other OpenCode windows.  When another window saves a higher total, adopt it
  // so all windows converge on the same number.
  // ---------------------------------------------------------------------------
  {
    const dailyFilePath = getDailyUsagePath();
    let dailySyncDebounce: ReturnType<typeof setTimeout> | undefined;
    let dailyFsWatcher: ReturnType<typeof fs.watch> | undefined;

    const reloadDaily = (): void => {
      if (!backfillComplete) { return; } // don't interfere while backfill is running
      try {
        if (!fs.existsSync(dailyFilePath)) { return; }
        const raw = JSON.parse(fs.readFileSync(dailyFilePath, "utf8")) as { date?: string; costUSD?: number; tokens?: number; messages?: number; source?: string };
        if (raw.date !== todayLocal()) { return; }
        const fileCost     = typeof raw.costUSD  === "number" ? raw.costUSD  : 0;
        const fileTokens   = typeof raw.tokens   === "number" ? raw.tokens   : 0;
        const fileMessages = typeof raw.messages === "number" ? raw.messages : dailyMessages;
        // A DB-sourced write is authoritative (it may correct an inflated total).
        // A live write from another window only knows that window's replies, so
        // it may only raise our total — adopting a lower one loses cost.
        const fromDb = raw.source === "db";
        const differs = Math.abs(fileCost - dailyCostUSD) > 0.0001 || Math.abs(fileTokens - dailyTokens) > 10;
        if (differs && (fromDb || fileCost > dailyCostUSD)) {
          dailyCostUSD  = fileCost;
          dailyTokens   = fileTokens;
          dailyMessages = fileMessages;   // keep the tok/msg average consistent with the adopted totals
        }
      } catch { /* best-effort */ }
    };

    const onDailyChange = (): void => {
      if (dailySyncDebounce !== undefined) { clearTimeout(dailySyncDebounce); }
      dailySyncDebounce = setTimeout(() => { dailySyncDebounce = undefined; reloadDaily(); }, 150);
    };

    const startDailyWatcher = (): void => {
      if (dailyFsWatcher !== undefined) { return; }
      try {
        dailyFsWatcher = fs.watch(dailyFilePath, { persistent: false }, onDailyChange);
        dailyFsWatcher.on("error", () => { dailyFsWatcher?.close(); dailyFsWatcher = undefined; });
      } catch { /* file may not exist yet — dailyWatchBootstrap will retry */ }
    };

    startDailyWatcher();
    const dailyWatchBootstrap = setInterval(() => {
      if (dailyFsWatcher !== undefined) { clearInterval(dailyWatchBootstrap); return; }
      startDailyWatcher();
      if (dailyFsWatcher !== undefined) { clearInterval(dailyWatchBootstrap); }
    }, 10_000);
    disposers.push(() => {
      clearInterval(dailyWatchBootstrap);
      if (dailySyncDebounce !== undefined) { clearTimeout(dailySyncDebounce); }
      dailyFsWatcher?.close();
      dailyFsWatcher = undefined;
    });
  }

  // ---------------------------------------------------------------------------
  // Tool definition
  // ---------------------------------------------------------------------------
  const codotchiTool = tool({
    description:
      "Interact with your codotchi virtual pet. Use action='status' to see current stats, " +
      "or one of: feed, pat, sleep, clean, medicine, on, off. " +
      "Use warnthreshold <value> or shoutthreshold <value> to set the daily USD cost thresholds " +
      "at which the pet's speech changes tone (defaults: warn=$30, shout=$50). " +
      "Use rename <new-name> to rename the built-in OpenCode pet only (does not affect VS Code or PyCharm pets). " +
      "Actions apply to all currently active pets (VS Code, PyCharm, or the built-in OpenCode pet). " +
      "This tool reads state from VS Code, PyCharm, and the local OpenCode pet — do NOT use any other codotchi tool.",
    args: {
      action: tool.schema
        .enum(["status", "feed", "snack", "pat", "play", "sleep", "clean", "medicine", "on", "off", "warnthreshold", "shoutthreshold", "rename"])
        .describe("The action to perform"),
      value: tool.schema
        .number()
        .optional()
        .describe("Numeric USD value for warnthreshold or shoutthreshold actions"),
      name: tool.schema
        .string()
        .optional()
        .describe("New name for the OpenCode pet — used with the rename action only"),
    },
    async execute({ action, value, name }, context) {
      // Drain any queued tick notifications to prepend to this result
      const notification = drainNotification();
      const ret = (s: string): string => { lastToolOutput = s; return s; };

      const active = getActivePets();

      // Build panel title from active pets
      const titleParts = active.map(p => `${p.state.name} [${p.state.stage}]`);
      context.metadata({ title: titleParts.join(" / ") || "codotchi" });

      // ---------------------------------------------------------------------------
      // on / off — toggle ASCII art display
      // ---------------------------------------------------------------------------
      if (action === "on") {
        if (terminalEnabled) {
          return ret(notification + "ASCII art is already enabled.");
        }
        terminalEnabled = true;
        saveTerminalEnabled();
        const art = artHeader();
        return ret(notification + art + "ASCII art enabled.");
      }

      if (action === "off") {
        terminalEnabled = false;
        saveTerminalEnabled();
        return ret(notification + "ASCII art disabled. Stats will be shown as plain text.");
      }

      // ---------------------------------------------------------------------------
      // warnthreshold / shoutthreshold — configure cost speech tiers
      // ---------------------------------------------------------------------------
      if (action === "warnthreshold" || action === "shoutthreshold") {
        if (typeof value !== "number" || value <= 0) {
          return ret(notification + `Please provide a positive number, e.g. /codotchi ${action} 40`);
        }
        if (action === "warnthreshold") {
          if (value >= costShoutThreshold) {
            return ret(notification + `Warning threshold ($${value}) must be less than the shout threshold ($${costShoutThreshold}). Adjust the shout threshold first if needed.`);
          }
          costWarnThreshold = value;
          savePluginConfig();
          return ret(notification + `Cost warning threshold set to $${value}. The pet will switch to a warning tone when daily spend reaches this amount.`);
        } else {
          if (value <= costWarnThreshold) {
            return ret(notification + `Shout threshold ($${value}) must be greater than the warning threshold ($${costWarnThreshold}). Adjust the warn threshold first if needed.`);
          }
          costShoutThreshold = value;
          savePluginConfig();
          return ret(notification + `Cost shouting threshold set to $${value}. The pet will shout in ALL CAPS when daily spend reaches this amount.`);
        }
      }
      // ---------------------------------------------------------------------------
      // rename — change the OpenCode-local pet's display name
      // ---------------------------------------------------------------------------
      if (action === "rename") {
        const newName = (name ?? "").trim();
        if (!newName) {
          return ret(notification + "Please provide a name, e.g. /codotchi rename Pixel");
        }
        if (!localPetState) {
          return ret(notification + "No local OpenCode pet to rename.");
        }
        const oldName = localPetState.name;
        localPetState = { ...localPetState, name: newName } as PetState;
        saveLocalState();
        const bubble = terminalEnabled && localPetState
          ? buildSpeechBubble(localPetState.stage, localPetState.mood,
              `${oldName} is now ${newName}. Got it.`,
              newName, localPetState.spriteType, "[OpenCode]")
          : `[OpenCode] ${newName}: ${oldName} is now ${newName}. Got it.`;
        return ret(notification + bubble);
      }

      // ---------------------------------------------------------------------------
      // All other actions — at least one pet is always available (local pet fallback)
      // ---------------------------------------------------------------------------
      const allDead = active.every(p => !p.state.alive);
      if (allDead) {
        const names = active.map(p => p.state.name).join(" and ");
        return ret(notification + `${names} has passed away. Start a new game in VS Code or PyCharm to continue, or wait — the OpenCode pet will respawn automatically.`);
      }

      // Only operate on alive pets
      const alivePets = active.filter(p => p.state.alive);

      switch (action) {
        case "status": {
          // Show stacked status block (art + stats) for each active alive pet.
          const blocks = alivePets.map(p => {
            const s = p.state;
            const ideLabel = p.ide === "vscode" ? "[VS Code]" : p.ide === "pycharm" ? "[PyCharm]" : "[OpenCode]";
            
            // OpenCode-local pet: show ASCII art with cost, no stat bars
            if (p.ide === "opencode") {
              const _1h1 = lastHourUsage();
              const { message: costMsg } = buildContextualSpeech(s, sessionFilesEdited, Date.now() - sessionStartMs, lastFileEditMs > 0 ? Date.now() - lastFileEditMs : 0, sessionUserMessages, isOnProdBranch, dailyCostUSD, dailyTokens, costWarnThreshold, costShoutThreshold, _1h1.costUSD, _1h1.tokens, dailyMessages);
              const artBlock = terminalEnabled
                ? buildSpeechBubble(s.stage, s.mood, costMsg, s.name, s.spriteType, ideLabel)
                : "";
              const textStats = `${ideLabel} ${s.name} | Stage: ${s.stage} | Daily cost: ${formatCost(dailyCostUSD)}`;
              return (artBlock ? artBlock + "\n" : "") + textStats;
            }
            
            // IDE pets: show full stat blocks
            const statusBlock = terminalEnabled
              ? buildStatusBlock({
                  name: s.name, stage: s.stage, mood: s.mood,
                  hunger: s.hunger, happiness: s.happiness, energy: s.energy,
                  health: s.health, discipline: s.discipline, weight: s.weight,
                  ageDays: s.ageDays, alive: s.alive, sick: s.sick,
                  sleeping: s.sleeping, poops: s.poops, spriteType: s.spriteType,
                })
              : "";
            // Each pet prints once: the stat block, or a one-line summary when art is off.
            if (statusBlock) { return `${ideLabel}\n${statusBlock}`; }
            const r = Math.round;
            return `${ideLabel} ${s.name} | Stage: ${s.stage} | Hunger: ${r(s.hunger)} | Happiness: ${r(s.happiness)} | Energy: ${r(s.energy)} | Health: ${r(s.health)} | Weight: ${r(s.weight)}`;
          });
          return ret(notification + blocks.join("\n\n──────────────────────\n\n"));
        }

         case "feed": {
           const feedLines: string[] = [];
           for (const p of alivePets) {
             // Skip OpenCode-local pet
             if (p.ide === "opencode") {
               feedLines.push(`[OpenCode] I'm just a companion — I don't need feeding.`);
               continue;
             }
             const s = p.state;
             const meals = getMeals(p.ide);
             const pLabel = p.ide === "vscode" ? "VS Code" : "PyCharm";
             if (s.sleeping) {
               feedLines.push(`[${pLabel}] ${s.name} is sleeping and can't eat right now.`);
               continue;
             }
             // BUG-S04: a sick pet won't eat until it's had its medicine.
             if (s.sick) {
               feedLines.push(`[${pLabel}] ${s.name} is too sick to eat — give medicine first (/codotchi medicine).`);
               continue;
             }
             const next = feedMeal(s, meals);
             const refused = next.events.includes("meal_refused");
             if (!refused) { setMeals(p.ide, meals + 1); }
             setPetState(p.ide, next);
             saveIDEState(p.ide);
             const toast = buildToast(next.stage, refused
               ? `${next.name} is too full for another meal.`
               : `${next.name} enjoyed the meal! (hunger: ${next.hunger})`);
             feedLines.push((terminalEnabled
               ? buildSpeechBubble(next.stage, next.mood, refused ? "I'm too full!" : next.events.includes("attention_call_answered_craving") ? whimSpeech("craving") : "Yum!", next.name, next.spriteType) + "\n"
               : "") + toast + "\n" + (refused
               ? `[${pLabel}] Meal refused — ${next.name} has already had ${getMeals(p.ide)} meals this wake cycle.`
               : `[${pLabel}] Fed ${next.name}. Hunger: ${next.hunger}/100, Weight: ${next.weight}.`));
           }
           return ret(notification + feedLines.join("\n\n"));
         }

         case "snack": {
           const snackLines: string[] = [];
           for (const p of alivePets) {
             // Skip OpenCode-local pet
             if (p.ide === "opencode") {
               snackLines.push(`[OpenCode] I'm just a companion — I don't need snacks.`);
               continue;
             }
             const s = p.state;
             const pLabel = p.ide === "vscode" ? "VS Code" : "PyCharm";
             if (s.sleeping) {
               snackLines.push(`[${pLabel}] ${s.name} is sleeping and can't eat right now.`);
               continue;
             }
             // BUG-S04: a sick pet won't have a snack until it's had its medicine.
             if (s.sick) {
               snackLines.push(`[${pLabel}] ${s.name} is too sick to have a snack — give medicine first (/codotchi medicine).`);
               continue;
             }
             // The IDE drops the snack on the floor and the pet walks to it; here it's eaten straight away.
             const placed = startSnack(s);
             if (placed.events.includes("snack_refused")) {
               snackLines.push(`[${pLabel}] Snack refused — no more snacks for ${s.name} right now.`);
               continue;
             }
             const answered = placed.events.includes("attention_call_answered_craving");
             const next = consumeSnack(placed);
             setPetState(p.ide, next);
             saveIDEState(p.ide);
             const gotSick = next.events.includes("became_sick");
             snackLines.push((terminalEnabled
               ? buildSpeechBubble(next.stage, next.mood, gotSick ? "Ugh, too many snacks..." : answered ? whimSpeech("craving") : "Crunch!", next.name, next.spriteType) + "\n"
               : "") + `[${pLabel}] Gave ${next.name} a snack. Hunger: ${next.hunger}/100, Happiness: ${next.happiness}.` +
               (gotSick ? ` ${next.name} ate too many snacks in a row and feels sick.` : ""));
           }
           return ret(notification + snackLines.join("\n\n"));
         }

         case "pat": {
           const patLines: string[] = [];
           for (const p of alivePets) {
             // Skip OpenCode-local pet
             if (p.ide === "opencode") {
               patLines.push(`[OpenCode] I'm just a companion — I don't need pats.`);
               continue;
             }
             const s = p.state;
             const pLabel = p.ide === "vscode" ? "VS Code" : "PyCharm";
             if (s.sleeping) {
               patLines.push(`[${pLabel}] ${s.name} is sleeping.`);
               continue;
             }
             const next = pat(s);
             const refused = next.events.includes("pat_refused_no_energy");
             setPetState(p.ide, next);
             saveIDEState(p.ide);
             const toast = buildToast(next.stage, refused
               ? `${next.name} is too tired even for a pat.`
               : `${next.name} enjoyed the pat!`);
             patLines.push((terminalEnabled
               ? buildSpeechBubble(next.stage, next.mood, refused ? "Too tired..." : next.events.includes("attention_call_answered_pat") ? whimSpeech("pat") : "Yay!", next.name, next.spriteType) + "\n"
               : "") + toast + "\n" + (refused
               ? `[${pLabel}] Pat refused — ${next.name} is too exhausted.`
               : `[${pLabel}] Patted ${next.name}. Happiness: ${next.happiness}.`));
           }
           return ret(notification + patLines.join("\n\n"));
         }

         case "play": {
           const playLines: string[] = [];
           for (const p of alivePets) {
             // Skip OpenCode-local pet
             if (p.ide === "opencode") {
               playLines.push(`[OpenCode] I'm just a companion — I don't need games.`);
               continue;
             }
             const s = p.state;
             const pLabel = p.ide === "vscode" ? "VS Code" : "PyCharm";
             if (s.sleeping) {
               playLines.push(`[${pLabel}] ${s.name} is sleeping.`);
               continue;
             }
             // BUG-S04: a sick pet won't play until it's had its medicine.
             if (s.sick) {
               playLines.push(`[${pLabel}] ${s.name} is too sick to play — give medicine first (/codotchi medicine).`);
               continue;
             }
             // No mini-game in the terminal — play() applies the stat changes and answers a play call.
             const next = play(s);
             const refused = next.events.includes("play_refused_no_energy");
             if (!refused) {
               setPetState(p.ide, next);
               saveIDEState(p.ide);
             }
             const answered = next.events.includes("attention_call_answered_play");
             playLines.push((terminalEnabled
               ? buildSpeechBubble(next.stage, next.mood, refused ? "Too tired to play..." : answered ? whimSpeech("play") : "That was fun!", next.name, next.spriteType) + "\n"
               : "") + (refused
               ? `[${pLabel}] Play refused — ${next.name} is too tired.`
               : `[${pLabel}] Played with ${next.name}. Happiness: ${next.happiness}, Energy: ${next.energy}.`));
           }
           return ret(notification + playLines.join("\n\n"));
         }

         case "sleep": {
           const sleepLines: string[] = [];
           for (const p of alivePets) {
             // Skip OpenCode-local pet
             if (p.ide === "opencode") {
               sleepLines.push(`[OpenCode] I'm just a companion — I don't sleep.`);
               continue;
             }
             const pLabel = p.ide === "vscode" ? "VS Code" : "PyCharm";
             const next = sleep(p.state);
             const already = next.events.includes("already_sleeping");
             setPetState(p.ide, next);
             saveIDEState(p.ide);
             sleepLines.push((terminalEnabled
               ? buildSpeechBubble(next.stage, next.mood, already ? "Already snoozing. Zzzz..." : "Goodnight!", next.name, next.spriteType) + "\n"
               : "") + (already
               ? `[${pLabel}] ${next.name} is already sleeping.`
               : `[${pLabel}] ${next.name} is now sleeping. Energy will recharge.`));
           }
           return ret(notification + sleepLines.join("\n\n"));
         }

         case "clean": {
           const cleanLines: string[] = [];
           for (const p of alivePets) {
             // Skip OpenCode-local pet
             if (p.ide === "opencode") {
               cleanLines.push(`[OpenCode] I'm just a companion — I don't need cleaning.`);
               continue;
             }
             const pLabel = p.ide === "vscode" ? "VS Code" : "PyCharm";
             const next = clean(p.state);
             const already = next.events.includes("already_clean");
             setPetState(p.ide, next);
             saveIDEState(p.ide);
             const toast = buildToast(next.stage, already
               ? `${next.name}'s area is already clean.`
               : `Cleaned up after ${next.name}.`);
             cleanLines.push((terminalEnabled
               ? buildSpeechBubble(next.stage, next.mood, already ? "Already spotless!" : "Thanks for cleaning!", next.name, next.spriteType) + "\n"
               : "") + toast + "\n" + (already
               ? `[${pLabel}] Nothing to clean — ${next.name}'s area is already spotless.`
               : `[${pLabel}] Cleaned up ${next.name}'s mess.`));
           }
           return ret(notification + cleanLines.join("\n\n"));
         }

         case "medicine": {
           const medLines: string[] = [];
           for (const p of alivePets) {
             // Skip OpenCode-local pet
             if (p.ide === "opencode") {
               medLines.push(`[OpenCode] I'm just a companion — I don't need medicine.`);
               continue;
             }
             const s = p.state;
             const pLabel = p.ide === "vscode" ? "VS Code" : "PyCharm";
             if (!s.sick) {
               medLines.push(`[${pLabel}] ${s.name} is not sick — medicine not needed.`);
               continue;
             }
             const next = giveMedicine(s);
             const cured = next.events.includes("cured");
             setPetState(p.ide, next);
             saveIDEState(p.ide);
             const toast = buildToast(next.stage, cured
               ? `${next.name} is cured!`
               : `Gave ${next.name} medicine (${next.medicineDosesGiven}/3 doses).`);
             medLines.push((terminalEnabled
               ? buildSpeechBubble(next.stage, next.mood, cured ? "I feel better!" : "Medicine time...", next.name, next.spriteType) + "\n"
               : "") + toast + "\n" + (cured
               ? `[${pLabel}] ${next.name} has been cured!`
               : `[${pLabel}] Gave medicine to ${next.name}. Doses given: ${next.medicineDosesGiven}/3.`));
           }
           return ret(notification + medLines.join("\n\n"));
         }

        default:
          return ret(notification + artHeader() + "Unknown action. Use one of: status, feed, snack, pat, play, sleep, clean, medicine, on, off, warnthreshold, shoutthreshold.");
      }
    },
  });

  // ---------------------------------------------------------------------------
  // Event hooks
  // ---------------------------------------------------------------------------
  return {
    tool: {
      codotchi: codotchiTool,
    },

    async "tool.execute.after"({ tool: toolName }, output) {
      if (toolName === "codotchi") {
        output.output = stripAnsi(lastToolOutput);
      }
    },

    async event({ event }) {
      // file.edited → code activity reward (throttled), applied to all alive pets
      if (event.type === "file.edited") {
        isIdle = false;
        sessionFilesEdited += 1;
        lastFileEditMs = Date.now();
        const nowMs = Date.now();
        if (nowMs - lastCodeActivityMs >= CODE_ACTIVITY_THROTTLE_SECONDS * 1_000) {
          lastCodeActivityMs = nowMs;
          for (const ide of ["vscode", "pycharm"] as const) {
            const s = ide === "vscode" ? vscodePetState : pycharmPetState;
            if (s !== null && s.alive && !s.sleeping) {
              setPetState(ide, applyCodeActivity(s));
              saveIDEState(ide);
            }
          }
           // Also boost the local pet on file edits
           if (localPetState !== null && localPetState.alive && !localPetState.sleeping) {
             localPetState = pinnedCompanionStats(applyCodeActivity(localPetState));
             saveLocalState();
           }
        }
        return;
      }

      // session.idle → flag idle; fire diff notification if pending; offer help if prompting a lot
      if (event.type === "session.idle") {
        isIdle = true;
        void refreshDailyFromDb();
        saveIDEState("vscode");
        saveIDEState("pycharm");
        saveIDEState("opencode");
        if (pendingDiffSinceIdle) {
          pendingDiffSinceIdle = false;
          const livePets = getActivePets().filter(p => p.state.alive);
          for (const p of livePets) {
            const phrase = pickRandom(SESSION_DIFF_PHRASES);
            const ideLabel = p.ide === "vscode" ? "[VS Code]" : p.ide === "pycharm" ? "[PyCharm]" : "[OpenCode]";
            // Prepend so the diff phrase appears before any todo messages already queued
            prependNotification(terminalEnabled
              ? buildSpeechBubble(p.state.stage, p.state.mood, phrase, p.state.name, p.state.spriteType, ideLabel)
              : `${ideLabel} ${p.state.name}: ${phrase}`);
          }
        }
        if (sessionUserMessages >= 10 && !hasOfferedHelp) {
          hasOfferedHelp = true;
          const livePets = getActivePets().filter(p => p.state.alive);
          const rep = livePets[0];
          const phrase = "You've sent a lot of messages. Want me to take a bigger task off your hands?";
          if (rep) {
            const ideLabel = rep.ide === "vscode" ? "[VS Code]" : rep.ide === "pycharm" ? "[PyCharm]" : "[OpenCode]";
            queueNotification(terminalEnabled
              ? buildSpeechBubble(rep.state.stage, rep.state.mood, phrase, rep.state.name, rep.state.spriteType, ideLabel)
              : `${ideLabel} ${rep.state.name}: ${phrase}`);
          }
        }
        return;
      }

      // todo.updated → celebrate completions
      if (event.type === "todo.updated") {
        const newTodos = new Map<string, string>(
          event.properties.todos.map((t: { id: string; status: string }) => [t.id, t.status])
        );
        for (const todo of event.properties.todos) {
          const oldStatus = prevTodos.get(todo.id) ?? null;
          const livePets = getActivePets().filter(p => p.state.alive && !p.state.sleeping);
           if (oldStatus !== "completed" && todo.status === "completed") {
             for (const p of livePets) {
               const updated = applyCodeActivity(p.state);
               // Pin stats for local pet
               const final = p.ide === "opencode" ? pinnedCompanionStats(updated) : updated;
               setPetState(p.ide, final);
               saveIDEState(p.ide);
             }
            const phrase = pickRandom(TODO_COMPLETE_PHRASES)(todo.content);
            const rep = livePets[0];
            const ideLabel = rep ? (rep.ide === "vscode" ? "[VS Code]" : rep.ide === "pycharm" ? "[PyCharm]" : "[OpenCode]") : "";
            queueNotification(terminalEnabled && rep
              ? buildSpeechBubble(rep.state.stage, "happy", phrase, rep.state.name, rep.state.spriteType, ideLabel)
              : rep ? `${ideLabel} ${rep.state.name}: ${phrase}` : phrase);
          } else if (oldStatus !== "in_progress" && todo.status === "in_progress") {
            const phrase = `On it: ${todo.content}.`;
            const rep = livePets[0];
            const ideLabel = rep ? (rep.ide === "vscode" ? "[VS Code]" : rep.ide === "pycharm" ? "[PyCharm]" : "[OpenCode]") : "";
            queueNotification(terminalEnabled && rep
              ? buildSpeechBubble(rep.state.stage, rep.state.mood, phrase, rep.state.name, rep.state.spriteType, ideLabel)
              : rep ? `${ideLabel} ${rep.state.name}: ${phrase}` : phrase);
          } else if (oldStatus !== "cancelled" && todo.status === "cancelled") {
            const phrase = `Fair enough — ${todo.content} dropped.`;
            const rep = livePets[0];
            const ideLabel = rep ? (rep.ide === "vscode" ? "[VS Code]" : rep.ide === "pycharm" ? "[PyCharm]" : "[OpenCode]") : "";
            queueNotification(terminalEnabled && rep
              ? buildSpeechBubble(rep.state.stage, rep.state.mood, phrase, rep.state.name, rep.state.spriteType, ideLabel)
              : rep ? `${ideLabel} ${rep.state.name}: ${phrase}` : phrase);
          }
        }
        prevTodos = newTodos;
        return;
      }

      // session.diff → mark changes arrived
      if (event.type === "session.diff") {
        if (event.properties.diff && event.properties.diff.length > 0) {
          pendingDiffSinceIdle = true;
        }
        return;
      }

      // vcs.branch.updated → comment on branch switches + track prod branch
      if (event.type === "vcs.branch.updated") {
        const branch = event.properties.branch;
        if (branch) {
          isOnProdBranch = /^(main|master|prod.*)$/.test(branch) || /^release\//.test(branch);
          const phrase = isOnProdBranch
            ? `On ${branch}. Be careful — this is production.`
            : `Switched to ${branch}. New mission?`;
          const rep = getActivePets().filter(p => p.state.alive)[0];
          const ideLabel = rep ? (rep.ide === "vscode" ? "[VS Code]" : rep.ide === "pycharm" ? "[PyCharm]" : "[OpenCode]") : "";
          queueNotification(terminalEnabled && rep
            ? buildSpeechBubble(rep.state.stage, rep.state.mood, phrase, rep.state.name, rep.state.spriteType, ideLabel)
            : rep ? `${ideLabel} ${rep.state.name}: ${phrase}` : phrase);
        }
        return;
      }

      // server.connected → queue greeting
      if (event.type === "server.connected") {
        for (const p of getActivePets().filter(p => p.state.alive)) {
          const s = p.state;
          const ideLabel = p.ide === "vscode" ? "[VS Code]" : p.ide === "pycharm" ? "[PyCharm]" : "[OpenCode]";
          const greet = p.ide === "opencode"
            ? `I'm here. I live in OpenCode — no IDE needed.`
            : s.hunger < 30
            ? `Really hungry. Feed me when you get a chance (/codotchi feed)`
            : s.sick
            ? `Not feeling well. Need medicine (/codotchi medicine)`
            : s.energy < 20
            ? `Running on empty. Let me rest (/codotchi sleep)`
            : s.happiness < 30
            ? `Been a while. Pat me? (/codotchi pat)`
            : `Hey. Let's see what we build today.`;
          queueNotification(terminalEnabled
            ? buildSpeechBubble(s.stage, s.mood, greet, s.name, s.spriteType, ideLabel)
            : `${ideLabel} ${s.name}: ${greet}`);
        }
        return;
      }

      // session.status → resume from idle
      if (event.type === "session.status") {
        isIdle = false;
        return;
      }

      // session.created → reset all per-session counters
      if (event.type === "session.created") {
        sessionFilesEdited = 0;
        sessionStartMs = Date.now();
        lastFileEditMs = 0;
        sessionUserMessages = 0;
        countedUserMessageIds.clear();
        sessionCostUSD = 0;
        sessionTokens  = 0;
        localPetSessionMessages = 0;
        hasOfferedHelp = false;
        return;
      }

       // message.updated → count user messages; accumulate assistant cost + tokens
       if (event.type === "message.updated") {
         const info = event.properties?.info;
          if (info?.role === "user") {
            // message.updated fires several times per user message; count each ID once.
            const userMsgId: string = typeof info.id === "string" ? info.id : "";
            if (userMsgId && countedUserMessageIds.has(userMsgId)) { return; }
            if (userMsgId) { countedUserMessageIds.add(userMsgId); }
            sessionUserMessages += 1;
            return;
          }
         if (info?.role === "assistant" && typeof info.cost === "number") {
            // Only count the final completion event — skip intermediate streaming
            // chunks (those have time.completed = 0 or unset). Without this guard,
            // every streaming update increments dailyCostUSD with a partial cost,
            // causing the same message to be counted dozens of times.
            const completedAt = typeof info.time?.completed === "number" ? info.time.completed : 0;
            if (completedAt <= 0) { return; }   // still streaming — skip

            // Deduplicate by message ID: message.updated can fire multiple times
            // for the same message ID even after completion (e.g. metadata updates).
            // Roll the day over *before* the dedupe check: checkDayRollover()
            // clears countedMessageIds, so running it afterwards would forget
            // the message that triggered the rollover.
            if (backfillComplete) { checkDayRollover(); }
            const msgId: string = typeof info.id === "string" ? info.id : "";
            if (msgId && countedMessageIds.has(msgId)) { return; }
            if (msgId) { countedMessageIds.add(msgId); }

            const t = (info.tokens?.input ?? 0) + (info.tokens?.output ?? 0)
                    + (info.tokens?.reasoning ?? 0)
                    + (info.tokens?.cache?.read ?? 0) + (info.tokens?.cache?.write ?? 0);
            sessionCostUSD += info.cost;
            sessionTokens  += t;
            if (!backfillComplete) {
              // Backfill is still in-flight — hold this event to avoid double-counting.
              // It will be replayed (or discarded if already captured by backfill) once
              // backfillDailyUsage() finishes.
              pendingLiveEvents.push({ cost: info.cost, tokens: t, completedAt });
            } else if (completedAt >= todayStartLocalMs()) {
              // Bucket by completion time, not arrival time: a reply that
              // finished before midnight but whose event arrives after it
              // belongs to yesterday, not today.
              dailyCostUSD   += info.cost;
              dailyTokens    += t;
              dailyMessages  += 1;
              dailyDate = todayLocal();
              saveDailyUsage();
              // Push to rolling last-1h buffer
              costEvents.push({ completedAt, costUSD: info.cost, tokens: t });
            }
            // Message-based aging: increment total message count and advance stage if needed
            localPetTotalMessages += 1;
            advanceLocalPetStageIfNeeded();
          }
         return;
       }
    },
  };
};

// ---------------------------------------------------------------------------
// OpenCode V2 entry point
// ---------------------------------------------------------------------------
// V2 runs the same V1 hook object: the tool is re-registered through
// ctx.tool.transform and V2 events are translated into the V1 event shapes
// the existing handler understands (see v2Events.ts).

const CODOTCHI_TOOL_INPUT = {
  type: "object",
  properties: {
    action: {
      type: "string",
      enum: ["status", "feed", "snack", "pat", "play", "sleep", "clean", "medicine", "on", "off", "warnthreshold", "shoutthreshold", "rename"],
      description: "The action to perform",
    },
    value: { type: "number", description: "Numeric USD value for warnthreshold or shoutthreshold actions" },
    name: { type: "string", description: "New name for the OpenCode pet — used with the rename action only" },
  },
  required: ["action"],
  additionalProperties: false,
} as const;

// V2 has no session list in the plugin context; backfill falls back to Track A only.
const v2LegacyClient = {
  session: {
    list: async () => ({ data: [] }),
    messages: async () => ({ data: [] }),
  },
} as unknown as PluginInput["client"];

// Plain RPC definition (Rpc.define only validates and returns it), so the
// bundle needs no runtime import from @opencode/plugin. tui.tsx mirrors it.
const CODOTCHI_RPC = {
  id: "codotchi",
  methods: {
    snapshot: { output: { type: "object" } },
  },
  events: {
    updated: { schema: { type: "object" } },
    alert: {
      schema: {
        type: "object",
        properties: {
          title: { type: "string" },
          message: { type: "string" },
          variant: { type: "string" },
        },
        required: ["message"],
      },
    },
  },
};

type ShownPet = { ide: string; name: string; stage: string; message: string; emoji: string; lines: string[] };
/** Pet shown above the prompt. Refreshed at the end of each reply or every 5 minutes. */
let shownPet: ShownPet | null = null;
let speechDirty = true;
/** True while a reply is running; the bubble refreshes once when it goes idle. */
let replyBusy = false;
let shownSlot = -1;
/** Fixed order the pets take turns in. */
const PET_ORDER = ["vscode", "pycharm", "opencode"];
/**
 * Random per OpenCode window (process). Stored on globalThis so every plugin
 * copy inside one process shares it (no flicker), while separate windows get
 * different pets and phrases.
 */
const WINDOW_SALT: number = ((globalThis as any).__codotchiWindowSalt ??= Math.floor(Math.random() * 1_000_000));

/** Run fn with Math.random replaced by a PRNG seeded from `seed`, so every instance picks the same phrase. */
function withSeededRandom<T>(seed: string, fn: () => T): T {
  let h = 2166136261;
  for (let i = 0; i < seed.length; i++) { h = Math.imul(h ^ seed.charCodeAt(i), 16777619); }
  let a = h >>> 0;
  const original = Math.random;
  Math.random = () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  try { return fn(); } finally { Math.random = original; }
}
/** How often (in minutes) the pet above the prompt switches to another pet. */
const PET_SWAP_MINUTES = 2;
const PET_SWAP_MS = PET_SWAP_MINUTES * 60_000;
const TIER_ANSI = { green: "\x1b[32m", yellow: "\x1b[33m", red: "\x1b[31m" } as const;

/** The pet for `ide` if it still exists and is alive, regardless of the live window. */
function stillAlivePet(ide: string): ActivePet | undefined {
  const state = ide === "vscode" ? vscodePetState : ide === "pycharm" ? pycharmPetState : localPetState;
  return state && state.alive ? { ide: ide as ActivePet["ide"], state, live: false } : undefined;
}

function costTier(): "green" | "yellow" | "red" {
  if (dailyCostUSD >= costShoutThreshold) { return "red"; }
  if (dailyCostUSD >= costWarnThreshold) { return "yellow"; }
  return "green";
}

/** Everything the TUI needs: one pet's V1 speech bubble (ANSI lines) plus cost totals. */
function buildSnapshot(): Record<string, unknown> {
  const hour = lastHourUsage();
  const alive = getActivePets().filter(p => p.state.alive);
  const now = Date.now();
  // Keep showing the current pet while it is alive, even if its IDE briefly
  // drops out of the 60s "live" window — otherwise the display flickers.
  const current = shownPet ? (alive.find(p => p.ide === shownPet!.ide) ?? stillAlivePet(shownPet.ide)) : undefined;
  // The pet (art + speech) is frozen between refreshes: the speech changes once
  // at the end of each reply, and the pet switches every PET_SWAP_MINUTES
  // (or when the current pet is gone). Both the pet and the phrase are chosen
  // deterministically, so every plugin instance shows the same thing.
  const slot = Math.floor(now / PET_SWAP_MS);
  const swapDue = !current || slot !== shownSlot;
  if ((swapDue || speechDirty) && alive.length > 0) {
    speechDirty = false;
    let pick: ActivePet;
    if (swapDue) {
      const ordered = [...alive].sort((a, b) => PET_ORDER.indexOf(a.ide) - PET_ORDER.indexOf(b.ide));
      pick = ordered[(slot + WINDOW_SALT) % ordered.length];
      shownSlot = slot;
    } else {
      pick = current!;
    }
    // Cost figures are on the line under the pet, so the bubble only makes cost-tier remarks.
    const contextual = () => buildContextualSpeech(pick.state, sessionFilesEdited, now - sessionStartMs, lastFileEditMs > 0 ? now - lastFileEditMs : 0, sessionUserMessages, isOnProdBranch, dailyCostUSD, dailyTokens, costWarnThreshold, costShoutThreshold, 0, 0, dailyMessages, { remarksOnly: true });
    const speech = withSeededRandom(`${WINDOW_SALT}|${slot}|${pick.ide}|${dailyMessages}`, contextual);
    const s = pick.state;
    const ideLabel = pick.ide === "vscode" ? "[VS Code]" : pick.ide === "pycharm" ? "[PyCharm]" : "[OpenCode]";
    // No tier emoji in the art header: the cost line under the pet carries it.
    const lines = buildSpeechBubble(s.stage, s.mood, speech.message, s.name, s.spriteType, ideLabel, TIER_ANSI[costTier()])
      .split("\n")
      .filter(l => stripAnsi(l).trim().length > 0);
    shownPet = { ide: pick.ide, name: s.name, stage: s.stage, message: speech.message, emoji: speech.tierEmoji, lines };
  } else if (shownPet && !current) {
    shownPet = null;
  }
  const pets = shownPet ? [shownPet] : [];
  return {
    enabled: terminalEnabled,
    tier: costTier(),
    pets,
    petSlot: shownSlot,
    today: { costUSD: dailyCostUSD, tokens: dailyTokens, messages: dailyMessages },
    lastHour: { costUSD: hour.costUSD, tokens: hour.tokens },
    session: { costUSD: sessionCostUSD, tokens: sessionTokens },
    thresholds: { warn: costWarnThreshold, shout: costShoutThreshold },
    updatedAt: Date.now(),
  };
}

/** Only evolution, death and sickness are shown as toasts; other pet messages are dropped in V2. */
function isBigMoment(text: string): boolean {
  return /goodbye|farewell|full life|lived|journey|evolved|now a |growing up|sick|medicine/i.test(text);
}

function alertVariant(text: string): "info" | "success" | "warning" | "error" {
  if (/goodbye|farewell|full life|lived|journey/i.test(text)) { return "error"; }
  if (/evolved|now a |growing up/i.test(text)) { return "success"; }
  if (/sick|mess|hungry|critical|medicine/i.test(text)) { return "warning"; }
  return "info";
}

// V2 may run one plugin instance per location inside the same server process.
// Game state is module-global, so one leader instance owns the timers, the
// event subscription and the RPC; the others only register the tool.
let v2Leader: { refs: number; stop: () => void } | null = null;
let v2HooksPromise: Promise<Awaited<ReturnType<typeof plugin>>> | null = null;
/** Set by the leader instance; pushes a fresh snapshot to the TUI. */
let requestSidebarRefresh: () => void = () => { /* no leader yet */ };

async function setupV2(ctx: any): Promise<() => void> {
  const isLeader = v2HooksPromise === null;
  if (isLeader) {
    v2HooksPromise = plugin({ client: v2LegacyClient, directory: ctx.location?.directory } as unknown as PluginInput);
    v2Leader = { refs: 1, stop: () => { /* set once setup completes */ } };
  }
  const hooks = await v2HooksPromise!;
  const legacyTool = (hooks.tool as Record<string, any>).codotchi;

  let rpcRegistration: any = null;
  let refreshTimer: ReturnType<typeof setTimeout> | undefined;
  const emitUpdated = (): void => {
    if (refreshTimer !== undefined) { return; }
    refreshTimer = setTimeout(() => {
      refreshTimer = undefined;
      try { void rpcRegistration?.events.emit("updated", buildSnapshot()); } catch { /* best-effort */ }
    }, 250);
  };

  await ctx.tool.transform((editor: any) => {
    editor.add({
      name: "codotchi",
      description: legacyTool.description,
      input: CODOTCHI_TOOL_INPUT,
      async execute(input: any, context: any) {
        const out = await legacyTool.execute(input, {
          ...context,
          metadata: () => { /* V2 tool panel titles come from the tool name */ },
        });
        requestSidebarRefresh();
        return { content: stripAnsi(typeof out === "string" ? out : lastToolOutput) };
      },
    });
  });

  if (!isLeader) {
    let ownRpc: any = null;
    try { ownRpc = await ctx.rpc.register(CODOTCHI_RPC, { snapshot: async () => buildSnapshot() }); } catch { /* already registered here */ }
    v2Leader!.refs += 1;
    return () => { void ownRpc?.dispose?.(); releaseV2(); };
  }

  try {
    rpcRegistration = await ctx.rpc.register(CODOTCHI_RPC, { snapshot: async () => buildSnapshot() });
  } catch { /* RPC unavailable — the TUI simply shows nothing */ }
  requestSidebarRefresh = emitUpdated;

  notificationListener = (msg: string): void => {
    const alert = summariseNotification(msg);
    if (!alert.message) { return; }
    // Only big moments get a toast; the bubble sticks to session / usage remarks.
    if (!isBigMoment(alert.message)) { return; }
    try {
      void rpcRegistration?.events.emit("alert", { ...alert, variant: alertVariant(alert.message) });
    } catch { /* best-effort */ }
  };

  const controller = new AbortController();
  void (async () => {
    try {
      for await (const event of ctx.event.subscribe({ signal: controller.signal })) {
        const translated = translateV2Event(event);
        for (const legacy of translated) {
          try { await hooks.event?.({ event: legacy as any }); } catch { /* never break the stream */ }
          if (legacy.type === "session.status" || legacy.type === "message.updated") { replyBusy = true; }
        }
        // End of a reply: V2 may send session.idle and/or session.status → idle.
        // Refresh the speech once per reply, not once per idle signal.
        const endOfReply = event?.type === "session.idle" || (event?.type === "session.status" && event.data?.status?.type === "idle");
        if (endOfReply && replyBusy) { replyBusy = false; speechDirty = true; emitUpdated(); }
        if (translated.length > 0) { emitUpdated(); }
      }
    } catch { /* subscription closed */ }
  })();

  // Keep the sidebar's stats and costs fresh between replies (ticks).
  const pulse = setInterval(emitUpdated, TICK_INTERVAL_SECONDS * 1_000);

  v2Leader!.stop = () => {
    controller.abort();
    clearInterval(pulse);
    if (refreshTimer !== undefined) { clearTimeout(refreshTimer); }
    notificationListener = null;
    requestSidebarRefresh = () => { /* no leader */ };
    void rpcRegistration?.dispose?.();
    disposeCodotchi();
  };
  return () => { releaseV2(); };
}

function releaseV2(): void {
  if (!v2Leader) { return; }
  v2Leader.refs -= 1;
  if (v2Leader.refs > 0) { return; }
  v2Leader.stop();
  v2Leader = null;
  v2HooksPromise = null;
}

/** Stop timers and file watchers started by the plugin entry point. */
function disposeCodotchi(): void {
  while (disposers.length > 0) {
    try { disposers.pop()!(); } catch { /* best-effort */ }
  }
}

// Default export is readable by both loaders: V2 calls setup(), V1 (>= 1.18.29) calls server().
const codotchi = {
  id: "codotchi",
  setup: setupV2,
  server: plugin,
};

export default codotchi;
